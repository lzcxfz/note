package com.example.exceldemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExceldemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExceldemoApplication.class, args);
    }

}
