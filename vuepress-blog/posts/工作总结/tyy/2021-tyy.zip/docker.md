---
title: docker网络模式和DockerFile
---



##### 基本命令

* 启动容器：docker run 镜像名字
  * -t 打开一个终端，像使用交换机一样使用容器
  * -i 交互式访问
  * --name 容器名字
  * --network 指定网络
  * --rm 容器一停 自动删除
  * -d 剥离与当前终端的关系，否则会一直占用终端。
  * -p 端口映射

##### 网络模式

docker使用Linux的Namespace技术进行资源隔离，其中Network Namespace隔离网络。一个Network Namespace提供一份独立的网络环境，包括网卡、路由、iptable规则等。

* host模式：容器和宿主机共用一个Network Namespace。
* container模式：和另一个容器共用Network Namespace。
* none模式：没有Network Namespace，相当于没有网卡、路由等。
* bridge模式：为每一个容器创建一个Network Namespace。

##### 路径映射

docker run -v 主机目录:容器目录

##### Dockerfile

在空目录下新建Dockerfile文件，添加内容，运行docker build -t nginx:v3 .

nginx表示镜像名，v3是tag ，.表示上下文路径。

* FROM 指定基础镜像 。如:FROM nginx 

* RUN 后面跟指令 (shell 或者exec)，会在docker build的时候运行。如:RUN tar -vxf redis.tar.gz 

* CMD 和RUN 类似，后面跟指令，是在docker run 时运行。会被docker run的命令行参数指定的指令覆盖。

* ENTRYPOINT 与CMD类似，不会被docker run 命令行参数指定的指令覆盖。

* COPY 从上下文目录中复制文件到容器中，可以使用正则。如:COPY hom*.txt /mydir/

  * 如果是复制目录，其内部文件和子目录会被递归复制，但是这个目录本身不会被复制。需要把目录名字加在容器路径。

* ADD 和COPY类似，会自动解压本地的包，网络上的包会直接下载，不解压。

* ENV 设置环境变量,在后续的指令中可以用$使用这个变量。如:ENV NODE_VERSION=7.2.0 

* ARG 与ENV作用一样，但作用域不一样，只在Dockerfile内有效，也就是docker build 时才有效，构建好的镜像不存在此变量。

* VOLUE 定义匿名数据卷，在启动容器时忘记加 -v参数挂载数据卷时，会自动挂载到匿名卷。

* EXPOSE 仅仅只是声明端口。在运行时如果使用随机端口(docker run -p)，会自动随机映射到EXPOSE的端口。

* WORKDIR 指定工作目录。

* USER 指定执行后续命令的用户和用户组。

* HEALTHCHECK指定某个程序或指令来监控docker容器服务的运行状态。

* ONBUILD 延迟构建命令的执行。本次构建不执行这些命令，假设本次构建镜像名字:nginx1。

  下次构建 FROM nginx1 。在执行构建docker build 时，就会执行ONBUILD的指令。

* LABEL 添加元数据。如添加作者: LABEL com.lzc.image.author="lzc"

* MAINTAINER 指定制作者信息

  

  

  

