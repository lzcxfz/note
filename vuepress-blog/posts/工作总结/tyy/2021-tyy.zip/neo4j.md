---
title: 图形数据库neo4j
---



* 创建简单节点：create (节点名称:节点标签名称):

  ```CQL
   create (emp:Employee)
  ```

* 创建带有属性的节点: create (节点名称:节点标签名称 {属性名称:属性值,属性名称:属性值...})

  ```CQL
  create (dept:Dept {deptno:10,dname:"Accounting",location:"Hyderabad"})
  ```

* 查询Dept下所有的内容

  ```CQL
  match (dept:Dept) return dept
  ```

* 查询Dept标签下 id=45，dname="Accounting"的节点

  ```CQL
  match (dept:Dept {id:45,dname:"Accounting"}) return dept
  ```

* 查询Dept标签下 dname=“Accounting" 的节点  （使用where）

  ```CQL
  match (dept:Dept) where dept.dname="Accounting" return dept
  ```

* 检索Dept标签下所有节点的dname和deptno属性

  ```CQL
  match (dept:Dept) return dept.dname,dept.deptno
  ```

* 在现有的节点上创建没有属性的关系

  节点1：e:Customer，节点2： cc:CreditCard

  ```CQL
  match (e:Customer),(cc:CreditCard) create (e)-[r:DO_SHOPPING_WITH]->(cc)
  ```

  r:关系名称。

* 在现有的节点上创建带属性的关系。

  ```CQL
  match(e:Customer),(cc:CreditCard) create (cust)-[r:DO_SHOPPING_With{shopdate:"12/12/2021",price:5000}]->(cc) return r
  ```

  r:关系名称。{shopdate:"12/12/2021",price:5000}，关系的属性和值。

* 使用新节点创建没有属性的关系

  ```CQL
  create (fb1:FaceBookProfile1)-[like:LIKES]->(fb2:FaceBookProfile2)
  ```

* 使用新节点创建带有属性的关系

  ```CQL
  CREATE (video1:YoutubeVideo1{title:"Action Movie1",updated_by:"Abc",uploaded_date:"10/10/2010"})
  -[movie:ACTION_MOVIES{rating:1}]->
  (video2:YoutubeVideo2{title:"Action Movie2",updated_by:"Xyz",uploaded_date:"12/12/2012"}) 
  ```

* 检索关系节点的详细信息

  ```CQL
  match (cust)-[r:DO_SHOPPING_WITH]->(cc) 
  return cust,cc
  ```

* 多个标签到节点

  ```CQL
  CREATE (m:Movie:Cinema:Film:Picture)
  ```

* 为关系创建标签

  ```CQL
  CREATE (p1:Profile1)-[r1:LIKES]->(p2:Profile2)
  ```

* 删除节点

  ```CQL
  match (e:Employee) delete e
  ```

* 删除标签

  ```CQL
  MATCH (m:Movie) 
  REMOVE m:Picture
  ```

  - DELETE操作用于删除节点和关联关系。
  - REMOVE操作用于删除标签和属性。

* SET标签

  为book加上了title属性，且赋值。

  ```CQL
  MATCH (book:Book)
  SET book.title = 'superstar'
  RETURN book
  ```

* ORDER BY 和SQL一样 写在最后

* UNION 和SQL一样，注意如果两个两条语句查出来的属性是一样的，但是字段名不一样，要有as起别名，让他们一样，否则会报错。

* LIMIT 只有一个参数。显示记录的条数。

* SKIP 只有一个参数，跳过多少行。

* 它只显示一行，因为CQL MERGE命令检查该节点在数据库中是否可用。 如果它不存在，它创建新节点。 否则，它不创建新的。

* IN 

  ```CQL
  MATCH (e:Employee) 
  WHERE e.id IN [123,124]
  RETURN e.id,e.name,e.sal,e.deptno
  ```

  