---
title: gradle初体验
---



* maven不足：xml配置繁琐。

* gradle使用Groovy来声明项目设置。

* groovy基本语法

  ```groovy
  println "hello groovy"
  
  // 定义变量 弱类型
  def i =1
  println i
  
  def j ="哈哈"
  println j
  // 定义集合
  def list=['a','b']
  // 添加元素
  list << 'c'
  // 输出第三个
  println list.get(2)
  //定义 map
  def map=['key1':'value1','key2':'value2']
  // 添加
  map.key3='value3'
  //打印 key3的值
  println map.get("key3")
  
  // groovy中的闭包  定义一个闭包
  def b1={
      println "hello b1"
  }
  // 定义方法 参数是一个闭包
  def method1(Closure closure){
  //    执行 b1
      closure()
  }
  
  // 执行 method1  参数是闭包 b1
      method1(b1)
  
  // 定义一个带参数的闭包
  def b2 ={
      v->
          println "hello ${v}"
  }
  
  //定义一个方法 参数是闭包
  def method2(Closure closure){
      closure("b2")
  }
  //执行method2
  method2(b2)
  ```

* gradle 在Tasks中有build 可以打jar包。打包后在build文件夹下可以找到打包好的jar包。

* 例子

  ```groovy
  plugins {
      id 'java'
  }
  
  group 'com.lzc'
  version '1.0-SNAPSHOT'
  
  /**
   * 指定使用的仓库
   * mavenCentral()表示使用中央仓库
   *
   */
  repositories {
  //    mavenLocal()表示先从本地仓库找jar包
      mavenLocal()
      mavenCentral()
  }
  /**
   * 放依赖  group、name、version
   * testCompile 表示该jar包在测试的时候作用 (作用域)
   *
   */
  dependencies {
      testImplementation 'org.junit.jupiter:junit-jupiter-api:5.7.0'
      testRuntimeOnly 'org.junit.jupiter:junit-jupiter-engine:5.7.0'
  //    导入spring的包
      // https://mvnrepository.com/artifact/org.springframework/spring-context
      implementation group: 'org.springframework', name: 'spring-context', version: '5.3.13'
  
  }
  
  test {
      useJUnitPlatform()
  }
  ```

  