---
title: grpc基本使用
---

* 导入插件

  ```groovy
  id 'com.google.protobuf' version '0.8.11'
  ```

* 导入依赖

  ```groovy
  def grpcVersion = '1.26.0'
  dependencies {
      implementation "io.grpc:grpc-protobuf:${grpcVersion}"
      implementation "io.grpc:grpc-stub:${grpcVersion}"
      implementation "io.grpc:grpc-netty:${grpcVersion}"
  }
  ```

* 设置生成的类存放路径

  ```groovy
  sourceSets {
      main {
          java {
              srcDirs 'build/generated/source/proto/main/grpc'
              srcDirs 'build/generated/source/proto/main/java'
          }
      }
  }
  ```

* protobuf

  ```groovy
  protobuf {
      protoc { artifact = "com.google.protobuf:protoc:3.11.2" }
      plugins {
          grpc { artifact = "io.grpc:protoc-gen-grpc-java:${grpcVersion}" }
      }
      generateProtoTasks {
          all()*.plugins {
              grpc {}
          }
      }
  }
  ```

* 编写proto文件，用来生成代码。

  ```groovy
  package grpc;
  //每一个message文件都会有一个单独的class文件
  option java_multiple_files=true;
  //用于指定proto文件生成的java类的outerclass类名
  option java_outer_classname ="NameServiceProto";
  //用于标识生成的java文件的package
  option java_package ="com.lzc.demo.name";
  
  service NameService{
      //rpc 方法名 (参数) returns(返回值)
    rpc getName(NameRequest) returns (NameReply){}
  }
  //设置参数 
  //message 参数对象 
  message NameRequest{
    //1和2 表示这是第几个参数
    string firstName =1;
    string lastName =2;
  }
  
  message NameReply{
    //1和2 表示第几个返回值。
    string resName=1;
  }
  ```

  

* 用Gradle生成代码 generateProto，生成后再build文件夹中可以找到生成好的代码。

* 编写服务端

  ```java
  //首先继承生成类 serviceImplBase
  public class NameServer extends NameServiceGrpc.NameServiceImplBase {
  //重写我们在proto中定义的方法，实现功能。
      @Override
      public void getName(NameRequest request, StreamObserver<NameReply> responseObserver) {
  //		通过request可以获取到我们在proto中定义的参数，值就是客户端调用时传入的参数。
          String name = mergeName(request.getFirstName(), request.getLastName());
  //        处理完数据后，返回结果通过responseObserver进行设置。
          responseObserver.onNext(NameReply.newBuilder().setResName(name).build());
  //        结束设置
          responseObserver.onCompleted();
      }
  
      private String mergeName(String firstName,String lastName){
          return firstName+lastName;
      }
  
  
      public static void main(String[] args) throws IOException {
          //启动服务
          ServerBuilder.forPort(9999).addService(new NameServer()).build().start();
          System.out.println("nameserver run in 9999");
          while (true){
              //防止服务停止
          }
      }
  }
  ```

* 编写客户端 进行远程调用

  ```java
  //远程调用时，客户端把参数给stub，stub再以网络的形式发给服务端。
  public class NameClient {
      NameServiceGrpc.NameServiceBlockingStub stub=null;
      public NameClient() {
  //        设置server信息  ip+port
          ManagedChannel channel = ManagedChannelBuilder.forAddress("127.0.0.1", 9999)
  //		  用文本的形式
                  .usePlaintext().build();
  //        通过ServiceGrpc 创建stub
           stub= NameServiceGrpc.newBlockingStub(channel);
      }
  
      public static void main(String[] args) {
          NameClient nameClient = new NameClient();
  //		通过stub 调用方法 设置参数  调用后返回结果为reply类型们可以获取到返回值。
          NameReply reply = nameClient.stub.getName(NameRequest.newBuilder()
                  .setFirstName("lai").setLastName("zhuocheng").build());
          System.out.println(reply.getResName());
      }
  }
  ```